# Requirements 
- python 3.6.4
pip install Flask
pip install PyMySQL


# Run Application
Open terminal
```
FLASK_DEBUG=1 python app.py

127.0.0.1:1111
```
